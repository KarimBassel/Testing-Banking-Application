/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package javaapplication5;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author fady
 */
public class CircleTest {
    public CircleTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    @Test
    public void testGetArea() {
        Circle circle = new Circle(5);
        assertEquals(Math.PI * 25, circle.getArea(), 0);
    }

    @Test
    public void testGetPerimeter() {
        Circle circle = new Circle(7);
        assertEquals(2 * Math.PI * 7, circle.getPerimeter(), 0);
    }
}
