/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package testingproj;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author fady
 */
public class AccountTest {
    
    public AccountTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Starting Account class test: ");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("Account class test done!");
    }
    
    @Before
    public void setUp() {
        System.out.println("New test: ");
    }
    
    @After
    public void tearDown() {
        System.out.println("End of test.");
    }

    /**
     * Test of TransferMoney method, of class Account.
     */
    @Test
    public void testTransferMoney() {
        System.out.println("TransferMoney");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        double amount = 1.0;
        Account instance = new Account(12, "Fady", "Fady", 1001);
        instance.TransferMoney(f, amount);
        assertEquals(1000000, f.getBalance(), 0);
        assertEquals(1000, instance.getBalance(),0);
        
        Account f1 = new Account(206794, "Karim", "Bassel", 500000 );
        double amount1 = 500000.0;
        Account instance1 = new Account(206785, "Matthew", "Sherif", 500000);
        instance1.TransferMoney(f1, amount1);
        assertEquals(1000000, f1.getBalance(), 0);
        assertEquals(0, instance1.getBalance(),0);
    }

    /**
     * Test of buyItem method, of class Account.
     */
    @Test
    public void testBuyItem() {
        System.out.println("buyItem");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        double price = 999.0;
        f.buyItem(price);
        assertEquals(999000, f.getBalance(), 0);
        
        double price1 = 10000.0;
        f.buyItem(price1);
        assertEquals(989000, f.getBalance(), 0);
        
        double price2 = 989000.0;
        f.buyItem(price2);
        assertEquals(0, f.getBalance(), 0);
    }

    /**
     * Test of payBill method, of class Account.
     */
    @Test
    public void testPayBill() {
        System.out.println("payBill");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        double price = 999;
        f.payBill(price);
        assertEquals(999000, f.getBalance(), 0);
        
        double price1 = 1000000;
        f.payBill(price1);
        assertEquals(999000, f.getBalance(), 0);
    }

    /**
     * Test of getId method, of class Account.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        assertEquals(123,f.getId());
    }

    /**
     * Test of getFirstName method, of class Account.
     */
    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        assertEquals("Shady",f.getFirstName());
    }

    /**
     * Test of getLastName method, of class Account.
     */
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        assertEquals("Emad",f.getLastName());
    }

    /**
     * Test of getBalance method, of class Account.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        assertEquals(999999,f.getBalance(), 0);
    }

    /**
     * Test of setId method, of class Account.
     */
    @Test
    public void testSetId() {
        System.out.println("setId");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        f.setId(7070);
        assertEquals(7070,f.getId());
    }

    /**
     * Test of setFirstName method, of class Account.
     */
    @Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        f.setFirstName("Karim");
        assertEquals("Karim",f.getFirstName());
    }

    /**
     * Test of setLastName method, of class Account.
     */
    @Test
    public void testSetLastName() {
        System.out.println("setLastName");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        f.setLastName("Matthew");
        assertEquals("Matthew",f.getLastName());
    }

    /**
     * Test of setBalance method, of class Account.
     */
    @Test
    public void testSetBalance() {
        System.out.println("setBalance");
        Account f = new Account(123, "Shady", "Emad", 999999 );
        f.setBalance(10);
        assertEquals(10,f.getBalance(), 0);
    }

    /**
     * Test of getNoOfAccounts method, of class Account.
     */
    @Test
    public void testGetNoOfAccounts() {
        System.out.println("getNoOfAccounts");
        assertEquals(12,Account.getNoOfAccounts());
        Account f = new Account(123, "Shady", "Emad", 999999 );
        assertEquals(13,Account.getNoOfAccounts());
    }
    
}
