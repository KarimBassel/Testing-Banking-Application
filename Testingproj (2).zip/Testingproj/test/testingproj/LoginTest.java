/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package testingproj;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author fady
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Starting Login test: ");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("Login test done! ");
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getAccount method, of class Login.
     */
    @Test
    public void testGetAccount() {
        System.out.println("getAccount");
        Login L = new Login();
        L.accounts[0] = new Account(1, "Shady", "Emad", 999999 );
        L.accounts[1] = new Account(12, "Karim", "Bassel", 1000000 );
        L.accounts[2] = new Account(123, "Matthew", "Sherif", 1000001 );
        L.accounts[3] = new Account(1234, "Fady", "Fahim", 1000002 );
        assertEquals(L.accounts[2], L.getAccount(123));
        assertEquals(L.accounts[1], L.getAccount(12));
    }
    
}
