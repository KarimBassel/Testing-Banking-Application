/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testingproj;

/**
 *
 * @author fady
 */
public class Account {
    int id;
    String FirstName, LastName;
    double Balance;
    static int noOfAccounts;

    public Account(int id, String FirstName, String LastName, double Balance) {
        this.id = id;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Balance = Balance;
        noOfAccounts++;
    }

    public Account() {
        noOfAccounts++;
    }
    
    public void TransferMoney(Account f, double amount){
        if (this.Balance >= amount){
            f.setBalance(f.getBalance()+amount);
            this.Balance -= amount;
            Notifications n = new Notifications("Transfer Successful! Current Balance is " + Balance);
            n.setVisible(true);
            return;
        }
        Notifications n = new Notifications("Insufficient Balance!");
        n.setVisible(true);
    }
    
    public void buyItem(double price){
        if(this.Balance >= price){
            this.Balance-=price;
            Notifications n = new Notifications("Item Successfully Bought. Current Balance is " + Balance);
            n.setVisible(true);
            return;
        }
        Notifications n = new Notifications("Insufficient Balance!");
        n.setVisible(true);
    }
       
    public void payBill(double price){
        if (this.Balance >= price){
            this.Balance-=price;
            Notifications n = new Notifications("Bill Paid Successful. Current Balance is " + Balance);
            n.setVisible(true);
            return;
        }
        Notifications n = new Notifications("Insufficient Balance!");
        n.setVisible(true);
    }
    
    public int getId() {
        return id;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public double getBalance() {
        return Balance;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public void setBalance(double Balance) {
        this.Balance = Balance;
    }

    public static int getNoOfAccounts() {
        return noOfAccounts;
    }
}
